// ─── Timer Engine (runs in both background and popup) ───────────

const DEFAULT_INTERVALS = [
  { label: 'FOCUS', durationMin: 25, hue: 0.08, initiatingTask: '' },
  { label: 'REST', durationMin: 5, hue: 0.48, initiatingTask: '' },
];

const POMODORO_CONFIG = {
  workMin: 25, shortBreakMin: 5, longBreakMin: 15, rounds: 4,
};

function generatePomodoro(cfg = POMODORO_CONFIG) {
  const intervals = [];
  for (let r = 1; r <= cfg.rounds; r++) {
    intervals.push({ label: 'WORK', durationMin: cfg.workMin, hue: 0.08, initiatingTask: '' });
    intervals.push({
      label: r < cfg.rounds ? 'BREAK' : 'LONG BREAK',
      durationMin: r < cfg.rounds ? cfg.shortBreakMin : cfg.longBreakMin,
      hue: 0.48, initiatingTask: '',
    });
  }
  return intervals;
}

function hueToColor(hue) {
  const h = hue * 360;
  return `hsl(${h}, 70%, 60%)`;
}

function expandRepeat(intervals, repeat) {
  if (!repeat || repeat.mode === 'none') return [...intervals];
  if (repeat.mode === 'times') {
    const result = [];
    for (let i = 0; i < repeat.repeatCount; i++) result.push(...intervals.map(iv => ({...iv})));
    return result;
  }
  if (repeat.mode === 'duration') {
    const result = [];
    let totalSecs = 0;
    const target = repeat.totalMinutes * 60;
    while (totalSecs < target) {
      for (const iv of intervals) {
        result.push({...iv});
        totalSecs += iv.durationMin * 60;
        if (totalSecs >= target) break;
      }
    }
    return result;
  }
  return [...intervals];
}

function isBreakInterval(interval) {
  if (!interval) return false;
  const l = interval.label.toLowerCase();
  return l.includes('break') || l.includes('rest');
}
