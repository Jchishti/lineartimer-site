// ─── State ──────────────────────────────────────────────────────
let mode = 'pomodoro';
let customIntervals = [...DEFAULT_INTERVALS];
let repeat = { mode: 'none', repeatCount: 2, totalMinutes: 60 };
let currentState = null;

const COLORS = [
  { name: 'amber', hue: 0.08 }, { name: 'teal', hue: 0.48 },
  { name: 'purple', hue: 0.78 }, { name: 'green', hue: 0.33 },
  { name: 'red', hue: 0.0 }, { name: 'blue', hue: 0.58 },
];

// ─── Init ───────────────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', async () => {
  // Restore saved custom intervals
  const data = await chrome.storage.local.get(['lastIntervals', 'lastRepeat', 'mode']);
  if (data.lastIntervals) customIntervals = data.lastIntervals;
  if (data.lastRepeat) repeat = data.lastRepeat;
  if (data.mode) mode = data.mode;

  setupModeButtons();
  setupControls();
  setupEditor();
  setupPresets();
  updateModeUI();

  // Get current state from background
  chrome.runtime.sendMessage({ action: 'getState' }, (s) => {
    if (s) { currentState = s; render(s); }
  });
});

// Listen for state updates from background
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.action === 'stateUpdate') {
    currentState = msg.state;
    render(msg.state);
  }
});

// ─── Render ─────────────────────────────────────────────────────
function render(s) {
  const iv = s.intervals[s.currentIndex];
  if (!iv) return;

  const totalSecs = iv.durationMin * 60;
  const progress = totalSecs > 0 ? 1 - s.remaining / totalSecs : 0;
  const color = hueToColor(iv.hue);
  const m = Math.floor(s.remaining / 60);
  const sec = Math.floor(s.remaining % 60);
  const isWinding = s.status === 'running' && s.remaining <= 10 && s.remaining > 0 && totalSecs > 10;
  const isHalfway = s.firedHalfway && progress < 0.55;

  // Phase label
  document.getElementById('phase-label').textContent = iv.label;
  document.getElementById('phase-label').style.color = color.replace('60%', '50%');

  // Initiating task
  const taskEl = document.getElementById('initiating-task');
  taskEl.textContent = iv.initiatingTask || '';

  // Countdown
  const cdEl = document.getElementById('countdown');
  cdEl.textContent = `${m}:${sec.toString().padStart(2, '0')}`;
  cdEl.style.color = isWinding ? '#fff' : color;
  cdEl.style.textShadow = `0 0 ${isWinding ? 20 : 12}px ${color}`;
  cdEl.className = isHalfway ? 'halfway-pulse' : isWinding ? 'winding' : '';

  // Counter
  document.getElementById('interval-counter').textContent = `${s.currentIndex + 1} of ${s.intervals.length}`;

  // Halfway
  const halfEl = document.getElementById('halfway-label');
  halfEl.classList.toggle('hidden', !isHalfway);

  // Next up
  const nextIdx = (s.currentIndex + 1) % s.intervals.length;
  const nextIv = s.intervals[nextIdx];
  const nextEl = document.getElementById('next-up');
  if (isWinding && nextIv) {
    nextEl.classList.remove('hidden');
    document.getElementById('next-dot').style.background = hueToColor(nextIv.hue);
    document.getElementById('next-name').textContent = nextIv.label;
    document.getElementById('next-name').style.color = hueToColor(nextIv.hue).replace('60%', '50%');
    document.getElementById('next-dur').textContent = `${nextIv.durationMin}m`;
  } else {
    nextEl.classList.add('hidden');
  }

  // Break reminder
  const breakEl = document.getElementById('break-reminder');
  const needsBreak = s.breakReminderMin > 0 && s.workSecsSinceBreak >= s.breakReminderMin * 60;
  breakEl.classList.toggle('hidden', !needsBreak);
  if (needsBreak) {
    document.getElementById('break-minutes').textContent = `${Math.floor(s.workSecsSinceBreak / 60)}m without rest`;
  }

  // Progress bar
  document.getElementById('progress-fill').style.width = `${progress * 100}%`;
  document.getElementById('progress-fill').style.background = color;

  // Session strip
  const strip = document.getElementById('session-strip');
  if (strip.children.length !== s.intervals.length) {
    strip.innerHTML = s.intervals.map((iv, i) =>
      `<div class="seg" style="background:${hueToColor(iv.hue)}"></div>`
    ).join('');
  }
  Array.from(strip.children).forEach((seg, i) => {
    seg.className = 'seg' + (i < s.currentIndex ? ' done' : i === s.currentIndex ? ' active' : '');
  });

  // Play button
  const playBtn = document.getElementById('btn-play');
  playBtn.textContent = s.status === 'running' ? '⏸' : '▶';
  playBtn.style.background = color;
}

// ─── Mode ───────────────────────────────────────────────────────
function setupModeButtons() {
  document.querySelectorAll('.mode-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      mode = btn.dataset.mode;
      updateModeUI();
      loadMode();
    });
  });
}

function updateModeUI() {
  document.querySelectorAll('.mode-btn').forEach(btn => {
    btn.classList.toggle('active', btn.dataset.mode === mode);
  });
  document.getElementById('edit-btn').classList.toggle('hidden', mode !== 'custom');
  document.getElementById('preset-btn').classList.toggle('hidden', mode !== 'custom');
}

function loadMode() {
  chrome.storage.local.set({ mode });
  if (mode === 'pomodoro') {
    chrome.runtime.sendMessage({ action: 'load', intervals: generatePomodoro(), repeat: { mode: 'none' } });
  } else {
    chrome.runtime.sendMessage({ action: 'load', intervals: customIntervals, repeat });
  }
}

// ─── Controls ───────────────────────────────────────────────────
function setupControls() {
  document.getElementById('btn-play').addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'togglePlayPause' });
  });
  document.getElementById('btn-reset').addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'reset' });
  });
  document.getElementById('btn-skip').addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'skip' });
  });
  document.getElementById('dismiss-break').addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'dismissBreak' });
  });
  // Initiating task click
  document.getElementById('initiating-task').addEventListener('click', () => {
    if (!currentState) return;
    const iv = currentState.intervals[currentState.currentIndex];
    if (!iv) return;
    const val = prompt('First step:', iv.initiatingTask || '');
    if (val !== null) {
      iv.initiatingTask = val;
      saveCustom();
    }
  });
}

// ─── Editor ─────────────────────────────────────────────────────
function setupEditor() {
  document.getElementById('edit-btn').addEventListener('click', showEditor);
  document.getElementById('editor-done').addEventListener('click', hideEditor);
  document.getElementById('add-interval').addEventListener('click', () => {
    customIntervals.push({ label: 'FOCUS', durationMin: 25, hue: 0.08, initiatingTask: '' });
    renderEditor();
  });

  // Repeat chips
  document.querySelectorAll('.repeat-chip').forEach(chip => {
    chip.addEventListener('click', () => {
      repeat.mode = chip.dataset.repeat;
      updateRepeatUI();
    });
  });
  document.getElementById('rep-minus').addEventListener('click', () => { if (repeat.repeatCount > 2) { repeat.repeatCount--; document.getElementById('rep-count').textContent = repeat.repeatCount; } });
  document.getElementById('rep-plus').addEventListener('click', () => { if (repeat.repeatCount < 50) { repeat.repeatCount++; document.getElementById('rep-count').textContent = repeat.repeatCount; } });
  document.getElementById('dur-minus').addEventListener('click', () => { if (repeat.totalMinutes > 5) { repeat.totalMinutes -= 5; document.getElementById('dur-count').textContent = repeat.totalMinutes; } });
  document.getElementById('dur-plus').addEventListener('click', () => { if (repeat.totalMinutes < 480) { repeat.totalMinutes += 5; document.getElementById('dur-count').textContent = repeat.totalMinutes; } });

  // Save preset
  document.getElementById('save-preset-btn').addEventListener('click', saveAsPreset);
}

function showEditor() {
  document.getElementById('timer-view').classList.add('hidden');
  document.getElementById('editor-view').classList.remove('hidden');
  renderEditor();
  updateRepeatUI();
}

function hideEditor() {
  document.getElementById('editor-view').classList.add('hidden');
  document.getElementById('timer-view').classList.remove('hidden');
  saveCustom();
  chrome.runtime.sendMessage({ action: 'load', intervals: customIntervals, repeat });
}

function renderEditor() {
  const list = document.getElementById('interval-list');
  list.innerHTML = customIntervals.map((iv, i) => `
    <div class="iv-row" data-index="${i}">
      <div class="iv-row-top">
        <input type="text" value="${iv.label}" data-field="label" data-i="${i}">
        <span class="dur-display">${iv.durationMin} min</span>
        <button class="step-btn" data-action="dec" data-i="${i}">−</button>
        <button class="step-btn" data-action="inc" data-i="${i}">+</button>
        <button class="iv-delete" data-i="${i}">⊖</button>
      </div>
      <div class="iv-task">
        <input type="text" placeholder="First step…" value="${iv.initiatingTask || ''}" data-field="task" data-i="${i}">
      </div>
      <div class="iv-colors">
        ${COLORS.map(c => `<div class="color-dot ${Math.abs(iv.hue - c.hue) < 0.01 ? 'selected' : ''}" style="background:${hueToColor(c.hue)}" data-hue="${c.hue}" data-i="${i}"></div>`).join('')}
      </div>
    </div>
  `).join('');

  // Event delegation
  list.addEventListener('input', (e) => {
    const i = parseInt(e.target.dataset.i);
    if (e.target.dataset.field === 'label') customIntervals[i].label = e.target.value;
    if (e.target.dataset.field === 'task') customIntervals[i].initiatingTask = e.target.value;
  });
  list.addEventListener('click', (e) => {
    const i = parseInt(e.target.dataset.i);
    if (e.target.dataset.action === 'dec' && customIntervals[i].durationMin > 1) {
      customIntervals[i].durationMin--;
      renderEditor();
    }
    if (e.target.dataset.action === 'inc' && customIntervals[i].durationMin < 120) {
      customIntervals[i].durationMin++;
      renderEditor();
    }
    if (e.target.classList.contains('iv-delete') && customIntervals.length > 1) {
      customIntervals.splice(i, 1);
      renderEditor();
    }
    if (e.target.classList.contains('color-dot')) {
      customIntervals[i].hue = parseFloat(e.target.dataset.hue);
      renderEditor();
    }
  });
}

function updateRepeatUI() {
  document.querySelectorAll('.repeat-chip').forEach(c => c.classList.toggle('active', c.dataset.repeat === repeat.mode));
  document.getElementById('repeat-times').classList.toggle('hidden', repeat.mode !== 'times');
  document.getElementById('repeat-duration').classList.toggle('hidden', repeat.mode !== 'duration');
  document.getElementById('rep-count').textContent = repeat.repeatCount;
  document.getElementById('dur-count').textContent = repeat.totalMinutes;
}

function saveCustom() {
  chrome.storage.local.set({ lastIntervals: customIntervals, lastRepeat: repeat });
}

// ─── Presets ────────────────────────────────────────────────────
function setupPresets() {
  document.getElementById('preset-btn').addEventListener('click', showPresets);
  document.getElementById('preset-done').addEventListener('click', hidePresets);
}

function showPresets() {
  document.getElementById('timer-view').classList.add('hidden');
  document.getElementById('preset-view').classList.remove('hidden');
  renderPresets();
}

function hidePresets() {
  document.getElementById('preset-view').classList.add('hidden');
  document.getElementById('timer-view').classList.remove('hidden');
}

async function renderPresets() {
  const data = await chrome.storage.local.get('presets');
  const presets = data.presets || [];
  const list = document.getElementById('preset-list');
  if (presets.length === 0) {
    list.innerHTML = '<div style="text-align:center;color:rgba(255,255,255,0.2);padding:40px">No saved presets</div>';
    return;
  }
  list.innerHTML = presets.map((p, i) => `
    <div class="preset-row" data-index="${i}">
      <div class="preset-dot" style="background:${hueToColor(p.intervals[0]?.hue || 0.08)}"></div>
      <div class="preset-info">
        <div class="preset-name">${p.name}</div>
        <div class="preset-desc">${p.intervals.map(iv => `${iv.label} ${iv.durationMin}m`).join(' → ')}</div>
      </div>
      <button class="preset-delete" data-pi="${i}">🗑</button>
    </div>
  `).join('');

  list.addEventListener('click', async (e) => {
    // Delete
    if (e.target.classList.contains('preset-delete')) {
      const pi = parseInt(e.target.dataset.pi);
      presets.splice(pi, 1);
      await chrome.storage.local.set({ presets });
      renderPresets();
      return;
    }
    // Load
    const row = e.target.closest('.preset-row');
    if (row) {
      const idx = parseInt(row.dataset.index);
      const p = presets[idx];
      customIntervals = p.intervals.map(iv => ({...iv}));
      repeat = p.repeat || { mode: 'none', repeatCount: 2, totalMinutes: 60 };
      saveCustom();
      chrome.runtime.sendMessage({ action: 'load', intervals: customIntervals, repeat });
      hidePresets();
    }
  });
}

async function saveAsPreset() {
  const name = prompt('Preset name:');
  if (!name) return;
  const data = await chrome.storage.local.get('presets');
  const presets = data.presets || [];
  // Replace if same name
  const idx = presets.findIndex(p => p.name === name);
  const preset = { name, intervals: customIntervals.map(iv => ({...iv})), repeat: {...repeat} };
  if (idx >= 0) presets[idx] = preset; else presets.push(preset);
  await chrome.storage.local.set({ presets });
  alert(`Saved "${name}"`);
}
