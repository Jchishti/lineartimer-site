// ─── Background Service Worker ──────────────────────────────────
importScripts('timer-engine.js');

let state = {
  status: 'idle', // idle | running | paused
  intervals: [],
  currentIndex: 0,
  remaining: 0, // seconds
  mode: 'pomodoro',
  repeat: { mode: 'none', repeatCount: 2, totalMinutes: 60 },
  workSecsSinceBreak: 0,
  breakReminderMin: 45,
  firedHalfway: false,
  lastTickSecond: -1,
};

// ─── Alarm-based ticker ─────────────────────────────────────────
const TICK_ALARM = 'timer-tick';
const TICK_MS = 1000;
let lastTickTime = null;

chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === TICK_ALARM) tick();
});

function startTicking() {
  lastTickTime = Date.now();
  chrome.alarms.create(TICK_ALARM, { periodInMinutes: TICK_MS / 60000 });
}

function stopTicking() {
  chrome.alarms.clear(TICK_ALARM);
  lastTickTime = null;
}

function tick() {
  if (state.status !== 'running') return;
  const now = Date.now();
  const elapsed = lastTickTime ? (now - lastTickTime) / 1000 : 1;
  lastTickTime = now;
  state.remaining = Math.max(0, state.remaining - elapsed);

  const interval = state.intervals[state.currentIndex];
  const totalSecs = interval ? interval.durationMin * 60 : 0;
  const progress = totalSecs > 0 ? 1 - state.remaining / totalSecs : 0;

  // Break tracking
  if (interval && !isBreakInterval(interval)) {
    state.workSecsSinceBreak += elapsed;
  } else {
    state.workSecsSinceBreak = 0;
  }

  // Halfway
  if (!state.firedHalfway && progress >= 0.5 && totalSecs > 0) {
    state.firedHalfway = true;
    playSound('halfway');
  }

  // Last 10 seconds tick
  if (state.remaining <= 10 && state.remaining > 0 && totalSecs > 10) {
    const sec = Math.ceil(state.remaining);
    if (sec !== state.lastTickSecond) {
      state.lastTickSecond = sec;
      playSound('tick');
    }
  } else {
    state.lastTickSecond = -1;
  }

  // Interval complete
  if (state.remaining <= 0) {
    playSound('transition');
    advance();
  }

  // Break reminder
  if (state.breakReminderMin > 0 && state.workSecsSinceBreak >= state.breakReminderMin * 60) {
    // Notify once
    if (!state._breakNotified) {
      state._breakNotified = true;
      chrome.notifications?.create('break-reminder', {
        type: 'basic',
        iconUrl: 'icons/icon128.png',
        title: 'Time for a break',
        message: `${Math.floor(state.workSecsSinceBreak / 60)}m without rest`,
      });
    }
  } else {
    state._breakNotified = false;
  }

  updateBadge();
  broadcastState();
}

function advance() {
  if (state.currentIndex + 1 < state.intervals.length) {
    state.currentIndex++;
  } else {
    state.currentIndex = 0;
  }
  const iv = state.intervals[state.currentIndex];
  state.remaining = iv ? iv.durationMin * 60 : 0;
  state.firedHalfway = false;
  state.lastTickSecond = -1;
}

// ─── Controls ───────────────────────────────────────────────────

function loadIntervals(intervals, repeat) {
  state.intervals = expandRepeat(intervals, repeat);
  state.repeat = repeat || state.repeat;
  state.currentIndex = 0;
  state.remaining = state.intervals[0]?.durationMin * 60 || 0;
  state.status = 'idle';
  state.workSecsSinceBreak = 0;
  state.firedHalfway = false;
  stopTicking();
  updateBadge();
  broadcastState();
}

function start() {
  if (state.intervals.length === 0) return;
  if (state.status === 'idle') {
    state.remaining = state.intervals[state.currentIndex]?.durationMin * 60 || 0;
  }
  state.status = 'running';
  startTicking();
  broadcastState();
}

function pause() {
  state.status = 'paused';
  stopTicking();
  updateBadge();
  broadcastState();
}

function skip() {
  advance();
  if (state.status === 'running') {
    lastTickTime = Date.now();
  }
  updateBadge();
  broadcastState();
}

function reset() {
  state.status = 'idle';
  state.currentIndex = 0;
  state.remaining = state.intervals[0]?.durationMin * 60 || 0;
  state.workSecsSinceBreak = 0;
  state.firedHalfway = false;
  stopTicking();
  updateBadge();
  broadcastState();
}

// ─── Badge ──────────────────────────────────────────────────────

function updateBadge() {
  if (state.status === 'idle') {
    chrome.action.setBadgeText({ text: '' });
    return;
  }
  const m = Math.floor(state.remaining / 60);
  const s = Math.floor(state.remaining % 60);
  const text = m > 0 ? `${m}m` : `${s}s`;
  chrome.action.setBadgeText({ text });

  const iv = state.intervals[state.currentIndex];
  if (iv) {
    const hsl = hueToColor(iv.hue);
    // Extract RGB-ish for badge
    chrome.action.setBadgeBackgroundColor({ color: '#333' });
  }
}

// ─── Audio (via offscreen document) ─────────────────────────────

let offscreenReady = false;

async function ensureOffscreen() {
  if (offscreenReady) return;
  try {
    await chrome.offscreen.createDocument({
      url: 'offscreen.html',
      reasons: ['AUDIO_PLAYBACK'],
      justification: 'Play timer audio cues',
    });
    offscreenReady = true;
  } catch (e) {
    // Already exists
    offscreenReady = true;
  }
}

async function playSound(type) {
  await ensureOffscreen();
  chrome.runtime.sendMessage({ action: 'playSound', type });
}

// ─── Message handling ───────────────────────────────────────────

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  switch (msg.action) {
    case 'getState':
      sendResponse(state);
      break;
    case 'load':
      loadIntervals(msg.intervals, msg.repeat);
      break;
    case 'start': start(); break;
    case 'pause': pause(); break;
    case 'skip': skip(); break;
    case 'reset': reset(); break;
    case 'togglePlayPause':
      state.status === 'running' ? pause() : start();
      break;
    case 'dismissBreak':
      state.workSecsSinceBreak = 0;
      state._breakNotified = false;
      broadcastState();
      break;
  }
});

function broadcastState() {
  chrome.runtime.sendMessage({ action: 'stateUpdate', state }).catch(() => {});
}

// ─── Init: restore last state ───────────────────────────────────
chrome.storage.local.get(['lastIntervals', 'lastRepeat', 'mode'], (data) => {
  const intervals = data.lastIntervals || DEFAULT_INTERVALS;
  const repeat = data.lastRepeat || { mode: 'none', repeatCount: 2, totalMinutes: 60 };
  loadIntervals(intervals, repeat);
});
